package com.nieblamistica.client;

import net.minecraftforge.common.ForgeConfigSpec;

/** Ajustes visuales en config/nieblamistica-client.toml (no afectan al servidor). */
public final class MistClientConfig {
    public static final ForgeConfigSpec SPEC;

    /** AUTO: niebla del juego sin shaders y capa de niebla con shaders. */
    public enum Mode { AUTO, VANILLA, OVERLAY, BOTH }

    public static final ForgeConfigSpec.EnumValue<Mode> FOG_MODE;
    public static final ForgeConfigSpec.DoubleValue OVERLAY_OPACITY;
    public static final ForgeConfigSpec.BooleanValue FORCE_SHADER_MODE;
    public static final ForgeConfigSpec.BooleanValue PARTICLES;
    public static final ForgeConfigSpec.DoubleValue PARTICLE_DENSITY;
    public static final ForgeConfigSpec.BooleanValue DEBUG_TEXT;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.push("visual");
        FOG_MODE = b.comment("AUTO = detecta shaders solo. VANILLA = solo niebla del juego. OVERLAY = solo capa de niebla en pantalla. BOTH = las dos.")
                .defineEnum("fogMode", Mode.AUTO);
        OVERLAY_OPACITY = b.comment("Intensidad de la capa de niebla en pantalla (0 = invisible, 1 = maxima). El centro de la pantalla siempre queda casi limpio.")
                .defineInRange("overlayOpacity", 0.65D, 0.0D, 1.0D);
        FORCE_SHADER_MODE = b.comment("Pon true si usas shaders pero el mod no los detecta (o si no ves la niebla).")
                .define("forceShaderMode", false);
        PARTICLES = b.comment("Motas de niebla suspendidas en el aire.")
                .define("particles", true);
        PARTICLE_DENSITY = b.comment("Cantidad de motas (1 = normal).")
                .defineInRange("particleDensity", 1.0D, 0.0D, 3.0D);
        DEBUG_TEXT = b.comment("Muestra arriba a la izquierda el modo de niebla, si hay shaders y la intensidad (para diagnosticar).")
                .define("debugText", false);
        b.pop();
        SPEC = b.build();
    }

    private MistClientConfig() {}
}
