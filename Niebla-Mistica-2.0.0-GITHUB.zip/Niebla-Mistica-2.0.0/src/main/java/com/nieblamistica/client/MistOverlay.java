package com.nieblamistica.client;

import com.nieblamistica.NieblaMistica;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.gui.overlay.ForgeGui;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Capa de niebla dibujada sobre la pantalla. Con shaders, la niebla del juego
 * la sustituye el paquete de shaders y no se ve; esta capa si.
 *
 * Esta pensada para no molestar: el centro queda casi limpio y la niebla se
 * concentra en los bordes y abajo (como niebla baja en el suelo).
 */
@Mod.EventBusSubscriber(modid = NieblaMistica.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class MistOverlay {
    private static final int FOG_R = 176;
    private static final int FOG_G = 184;
    private static final int FOG_B = 196;

    private MistOverlay() {}

    @SubscribeEvent
    public static void register(RegisterGuiOverlaysEvent event) {
        event.registerAbove(VanillaGuiOverlay.VIGNETTE.id(), "niebla_mistica", MistOverlay::render);
    }

    /** true si la capa debe dibujarse con la configuracion y los shaders actuales. */
    static boolean overlayEnabled() {
        return switch (MistClientConfig.FOG_MODE.get()) {
            case OVERLAY, BOTH -> true;
            case VANILLA -> false;
            default -> ShaderCompat.isActive();
        };
    }

    /** true si hay que aplicar la niebla propia del juego (distancia y color). */
    static boolean vanillaFogEnabled() {
        return switch (MistClientConfig.FOG_MODE.get()) {
            case VANILLA, BOTH -> true;
            case OVERLAY -> false;
            default -> !ShaderCompat.isActive();
        };
    }

    private static int argb(float alpha) {
        int a = (int) (Mth.clamp(alpha, 0.0F, 1.0F) * 255.0F);
        return (a << 24) | (FOG_R << 16) | (FOG_G << 8) | FOG_B;
    }

    private static void render(ForgeGui gui, GuiGraphics g, float partialTick, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        float intensity = MistClientState.getIntensity();

        if (MistClientConfig.DEBUG_TEXT.get() && mc.player != null) {
            g.drawString(mc.font, "Niebla Mistica | shaders: " + (ShaderCompat.isActive() ? "SI (" + ShaderCompat.getSource() + ")" : "no")
                    + " | capa: " + (overlayEnabled() ? "si" : "no") + " | intensidad: " + String.format("%.2f", intensity),
                    4, 4, 0xFFFFFF);
        }

        if (intensity <= 0.01F || mc.player == null || !overlayEnabled()) return;

        float strength = intensity * MistClientConfig.OVERLAY_OPACITY.get().floatValue();
        float time = mc.level != null ? (mc.level.getGameTime() + partialTick) : 0F;
        float breathe = 0.92F + 0.08F * Mth.sin(time * 0.02F);
        strength *= breathe;

        // 1) velo muy ligero sobre toda la pantalla (el centro casi no se nota)
        g.fill(0, 0, w, h, argb(strength * 0.10F));

        // 2) niebla baja: sube desde el borde inferior
        int groundBand = (int) (h * (0.38F + 0.05F * Mth.sin(time * 0.013F)));
        g.fillGradient(0, h - groundBand, w, h, argb(0F), argb(strength * 0.55F));

        // 3) techo de niebla: mucho mas suave
        int topBand = (int) (h * 0.22F);
        g.fillGradient(0, 0, w, topBand, argb(strength * 0.40F), argb(0F));

        // 4) laterales: tiras que se desvanecen hacia el centro
        int strips = 22;
        int bandWidth = Math.max(strips, (int) (w * 0.20F));
        int stripWidth = Math.max(1, bandWidth / strips);
        for (int k = 0; k < strips; k++) {
            float t = 1.0F - (k / (float) strips);
            int color = argb(strength * 0.42F * t * t);
            g.fill(k * stripWidth, 0, (k + 1) * stripWidth, h, color);
            g.fill(w - (k + 1) * stripWidth, 0, w - k * stripWidth, h, color);
        }
    }
}
