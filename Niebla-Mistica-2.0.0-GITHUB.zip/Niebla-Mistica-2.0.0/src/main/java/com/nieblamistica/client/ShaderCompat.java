package com.nieblamistica.client;

import java.lang.reflect.Method;

/**
 * Detecta si hay un paquete de shaders en uso (Iris, Oculus u OptiFine) sin
 * depender de ellos: todo se hace por reflexion, asi que el mod funciona igual
 * si no estan instalados.
 */
public final class ShaderCompat {
    private static boolean active;
    private static String source = "ninguno";

    private ShaderCompat() {}

    public static boolean isActive() {
        return active || MistClientConfig.FORCE_SHADER_MODE.get();
    }

    public static String getSource() {
        return MistClientConfig.FORCE_SHADER_MODE.get() ? "forzado por config" : source;
    }

    /** Se llama cada poco tiempo desde el tick del cliente. */
    public static void refresh() {
        String[] irisClasses = {"net.irisshaders.iris.api.v0.IrisApi", "net.coderbot.iris.api.v0.IrisApi"};
        for (String name : irisClasses) {
            try {
                Class<?> api = Class.forName(name);
                Object instance = api.getMethod("getInstance").invoke(null);
                Method inUse = api.getMethod("isShaderPackInUse");
                boolean result = (Boolean) inUse.invoke(instance);
                active = result;
                source = name.contains("irisshaders") ? "Iris/Oculus" : "Oculus";
                return;
            } catch (Throwable ignored) {
                // esa API no esta: probamos la siguiente
            }
        }
        try {
            Class<?> config = Class.forName("net.optifine.Config");
            boolean result = (Boolean) config.getMethod("isShaders").invoke(null);
            active = result;
            source = "OptiFine";
            return;
        } catch (Throwable ignored) {
            // OptiFine tampoco
        }
        active = false;
        source = "ninguno";
    }
}
