package com.nieblamistica;

import java.util.List;
import net.minecraftforge.common.ForgeConfigSpec;

/** Ajustes en config/nieblamistica-common.toml */
public final class MistConfig {
    public static final ForgeConfigSpec SPEC;

    public static final ForgeConfigSpec.BooleanValue SPONTANEOUS;
    public static final ForgeConfigSpec.DoubleValue CHANCE_PERCENT;
    public static final ForgeConfigSpec.IntValue CHECK_SECONDS;
    public static final ForgeConfigSpec.IntValue MIN_SECONDS;
    public static final ForgeConfigSpec.IntValue MAX_SECONDS;
    public static final ForgeConfigSpec.BooleanValue NOT_IN_PEACEFUL;
    public static final ForgeConfigSpec.BooleanValue PLAY_SOUND;
    public static final ForgeConfigSpec.BooleanValue MYSTIC_EVENTS;
    public static final ForgeConfigSpec.IntValue EVENT_INTERVAL;
    public static final ForgeConfigSpec.IntValue EXCALIBUR_PER_10000;
    public static final ForgeConfigSpec.BooleanValue ONLY_VANILLA_MOBS;
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> MOB_BLACKLIST;
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> DISABLED_EVENTS;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();

        b.push("mist");
        SPONTANEOUS = b.comment("Si es false, la niebla solo aparece con /mistica start.")
                .define("spontaneous", true);
        CHANCE_PERCENT = b.comment("Probabilidad (%) de que empiece la niebla en cada comprobacion.")
                .defineInRange("chancePercent", 8.0, 0.0, 100.0);
        CHECK_SECONDS = b.comment("Cada cuantos segundos se hace la comprobacion.")
                .defineInRange("checkIntervalSeconds", 30, 1, 3600);
        MIN_SECONDS = b.comment("Duracion minima de la niebla (segundos).")
                .defineInRange("minDurationSeconds", 60, 5, 7200);
        MAX_SECONDS = b.comment("Duracion maxima de la niebla (segundos).")
                .defineInRange("maxDurationSeconds", 180, 5, 7200);
        NOT_IN_PEACEFUL = b.comment("No aparece sola en dificultad Pacifica.")
                .define("notInPeaceful", true);
        PLAY_SOUND = b.comment("Suena un sonido inquietante cuando empieza la niebla.")
                .define("playSound", true);
        MYSTIC_EVENTS = b.comment("Activa los eventos sobrenaturales y el evento extremadamente raro de Excalibur.")
                .define("mysticEvents", true);
        EVENT_INTERVAL = b.comment("Cada cuantos segundos le puede ocurrir un acontecimiento a cada jugador durante la niebla.")
                .defineInRange("eventIntervalSeconds", 12, 1, 600);
        EXCALIBUR_PER_10000 = b.comment("Probabilidad de Excalibur: X de cada 10000 tiradas (2 = 0,02%). 0 lo desactiva.")
                .defineInRange("excaliburPer10000", 2, 0, 10000);
        ONLY_VANILLA_MOBS = b.comment("Las criaturas aleatorias de la niebla solo salen del juego base (recomendado en modpacks).")
                .define("onlyVanillaMobs", true);
        MOB_BLACKLIST = b.comment("Criaturas que nunca aparecen en la niebla. Ejemplo: [\"minecraft:warden\"]")
                .defineListAllowEmpty("mobBlacklist",
                        List.of("minecraft:warden", "minecraft:elder_guardian", "minecraft:giant", "minecraft:ravager"),
                        o -> o instanceof String);
        DISABLED_EVENTS = b.comment("Acontecimientos desactivados. Valores: mobs, susurro, emboscada, pulso, perdido, cazador, casa, estatuas, observador, silueta, animal, excalibur")
                .defineListAllowEmpty("disabledEvents", List.of(), o -> o instanceof String);
        b.pop();

        SPEC = b.build();
    }

    private MistConfig() {}
}
