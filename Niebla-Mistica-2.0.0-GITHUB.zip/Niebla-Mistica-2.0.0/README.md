# Niebla Mística 2.0.0

Mod de Minecraft Java **1.20.1 + Forge 47.x** (Java 17).

La Niebla Mística es un evento sobrenatural que aparece de forma espontánea en el Overworld. Cuando empieza, la visibilidad se reduce progresivamente mediante profundidad de niebla real, el color del mundo se desatura hacia un gris frío y aparecen pequeñas partículas suspendidas. Además, los monstruos cercanos se vuelven ligeramente más rápidos y ocurren eventos ambientales ocasionales dentro de la niebla.

## Qué hace

- Evento controlado por el servidor y sincronizado con todos los jugadores.
- Aparición espontánea (8 % cada 30 s por defecto), duración aleatoria de 1 a 3 minutos.
- Estado guardado en el mundo: si cierras y abres, la niebla sigue donde se quedó.
- Entrada y salida **suaves** (≈5 s de transición) en vez de un corte brusco.
- Solo se nota en el Overworld; bajo tierra se suaviza; agua y lava conservan su niebla normal.
- Partículas ambientales discretas alrededor del jugador.
- Monstruos hostiles cercanos reciben Velocidad I mientras están dentro de la niebla.
- Sonidos ambientales localizados y ocasionales durante el evento.
- Corrientes frías ocasionales que ralentizan brevemente al jugador.
- La niebla ya no usa una capa negra plana sobre toda la pantalla.
- Avisos en el chat al empezar y terminar.

## Comandos (operador, nivel 2)

```text
/mistica ayuda
/mistica start [segundos]            activa la niebla (duración aleatoria o concreta, 5-7200)
/mistica stop                        la quita
/mistica extender <segundos>         suma tiempo (o la activa si estaba apagada)
/mistica status                      estado y tiempo restante
/mistica eventos                     lista de acontecimientos
/mistica evento <tipo> [jugadores]   lanza un acontecimiento ahora mismo
/mistica excalibur [jugadores]       viaje de Excalibur (atajo)
/mistica rescatar [jugadores]        saca del bosque de Excalibur y devuelve al sitio
/mistica limpiar                     borra casas/estatuas/siluetas temporales
/mistica config                      muestra la configuración
/mistica espontanea <true|false>     activa/desactiva la aparición automática
/mistica probabilidad <0-100>        probabilidad (%) en cada comprobación
```

Tipos de evento: `mobs`, `susurro`, `emboscada`, `pulso`, `perdido`, `cazador`, `casa`,
`estatuas`, `observador`, `silueta`, `animal`, `excalibur`.

## Compatibilidad con shaders

Con shaders (Iris, Oculus u OptiFine) la niebla del juego la sustituye el paquete de shaders y no se ve.
El mod lo detecta solo y dibuja una **capa de niebla en pantalla** pensada para no molestar:
el centro queda casi limpio y la niebla se concentra en los bordes y abajo, como niebla baja.
Además aparecen más motas y bancos de niebla.

Archivo `config/nieblamistica-client.toml`: `fogMode` (AUTO / VANILLA / OVERLAY / BOTH), `overlayOpacity`,
`forceShaderMode`, `particles`, `particleDensity` y `debugText` (muestra si detecta shaders).

## Configuración del servidor

Archivo `config/nieblamistica-common.toml`:

| Opción | Por defecto | Qué hace |
|---|---|---|
| `spontaneous` | true | Si es false, solo aparece con `/mistica start` |
| `chancePercent` | 8.0 | Probabilidad (%) en cada comprobación |
| `checkIntervalSeconds` | 30 | Cada cuánto se comprueba |
| `minDurationSeconds` / `maxDurationSeconds` | 60 / 180 | Rango de duración |
| `notInPeaceful` | true | No aparece sola en Pacífico |
| `playSound` | true | Sonido al empezar |
| `mysticEvents` | true | Acontecimientos sobrenaturales |
| `eventIntervalSeconds` | 12 | Cada cuánto puede ocurrirle algo a cada jugador |
| `excaliburPer10000` | 2 | Probabilidad de Excalibur (2 = 0,02 %) |
| `onlyVanillaMobs` | true | Las criaturas aleatorias solo son del juego base |
| `mobBlacklist` | warden, elder_guardian... | Criaturas que nunca aparecen |
| `disabledEvents` | [] | Acontecimientos desactivados |

## Novedades 2.0.0

- Capa de niebla compatible con shaders y detección automática.
- Comandos nuevos: `extender`, `rescatar`, `limpiar`, `config`, `espontanea`, `probabilidad`, `ayuda`, y `evento` / `excalibur` con selector de jugadores.
- Los comandos avisan si un evento no pudo ejecutarse (antes decían "lanzado" aunque no hiciera nada).
- Excalibur: reintenta en hasta 14 lugares, evita océanos y rellena los cimientos del bosque.
- El estado de la niebla se sincroniza al entrar, cambiar de dimensión, reaparecer y cada 10 s (antes un jugador que entraba durante la niebla no la veía).
- Seguridad: al cerrar el servidor o desconectarse en un viaje de Excalibur se restaura el mundo.
- Rango de Forge ampliado a 47.x (antes exigía 47.3 exacto y el mod no cargaba en otras versiones).
- Configuración ampliada.

## Compilar

Con GitHub Actions (pestaña **Actions** → último *Build* → artefacto `niebla-mistica`), o en tu PC con JDK 17 y Gradle 8.1.x: `gradle build`. El `.jar` queda en `build/libs/`.

## Licencia

MIT.
