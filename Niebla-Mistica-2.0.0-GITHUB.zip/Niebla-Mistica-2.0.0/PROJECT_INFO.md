# Niebla Mística — proyecto

- Minecraft: 1.20.1
- Forge: 47.x (compilado con 47.3.0, funciona con cualquier 47.x)
- Java: 17
- Mod ID: nieblamistica
- Versión: 2.0.0
